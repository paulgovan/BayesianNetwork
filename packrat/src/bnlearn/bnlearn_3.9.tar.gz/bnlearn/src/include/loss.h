
/* from loss.c */
double c_entropy_loss(SEXP fitted, SEXP orig_data, int ndata, int by,
    double *res_sample, SEXP keep, int allow_singular, int debuglevel);

